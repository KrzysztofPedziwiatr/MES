import MatrixVector.Matrix;
import MatrixVector.Vector;

/**
 * Created by Chriss on 2016-11-05.
 */
public class Main {
    public static void main(String []agrs)
    {
        Net net = new Net();
        net.Calculate();
    }
}
