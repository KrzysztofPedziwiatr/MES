import MatrixVector.Matrix;
import MatrixVector.Vector;
import com.sun.org.apache.xpath.internal.operations.Number;

import javax.swing.text.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Created by Chriss on 2016-11-05.
 */
public class Net {
    public int NumberOfNodes;
    public int NumberOfElements;
    public Element []Elements;
    public Node []Nodes;
    public double q;
    public double Alpha;
    public double AmbientTemperature;

    Matrix H;
    Vector P;

    public Net() {  }

    public void Calculate()
    {
        try{
            BufferedReader in = new BufferedReader(new FileReader("Data.txt"));
            String str;
            while((str = in.readLine()) != null) {
                NumberOfElements = Integer.parseInt(str);
                NumberOfNodes = NumberOfElements + 1;
                H = new Matrix(NumberOfNodes);
                P = new Vector(NumberOfNodes);
                Elements = new Element[NumberOfElements];
                Nodes = new Node[NumberOfNodes];
                for (int k = 0; k < NumberOfElements; k++) {
                    Elements[k] = new Element();
                }
                str = in.readLine();
                for (int k = 0; k < NumberOfElements; k++) {
                    String[] array = str.split(";");
                    Elements[k].ID1 = Integer.parseInt(array[0]);
                    Elements[k].ID2 = Integer.parseInt(array[1]);
                    Elements[k].k = Double.parseDouble(array[2]);
                    Elements[k].s = Double.parseDouble(array[3]);
                    str = in.readLine();
                    if (str == null) break;
                }
                for (int k = 0; k < NumberOfNodes; k++) {
                    Nodes[k] = new Node();
                    Nodes[k].ID = k;
                }
                for (int k = 0; k < NumberOfNodes; k++) {
                    String[] array = str.split(";");
                    Nodes[k].x = Double.parseDouble(array[0]);
                    Nodes[k].BC = Integer.parseInt(array[1]);
                    str = in.readLine();
                    if (str == null) break;
                }
                q = Double.parseDouble(str);
                str = in.readLine();
                AmbientTemperature = Double.parseDouble(str);
                str = in.readLine();
                Alpha = Double.parseDouble(str);
                for (int k = 0; k < NumberOfElements; k++) {
                    int i1 = Elements[k].ID1;
                    int i2 = Elements[k].ID2;
                    Elements[k].l = Nodes[i2].x - Nodes[i1].x;
                }
            }
        }
        catch (IOException e)
        {
            System.out.println("Cannot read the txt file!");
        }
        //System.out.print("\nDANE WCZYTANO!\n");
        //PrintData();
        //PrintElements();
        //PrintNodes();

        //Wywolanie funkcji wyliczajacej macierze i wektory lokalne
        for(int i = 0; i < NumberOfElements; i++)
        {
            Node n1 = Nodes[Elements[i].ID1];
            Node n2 = Nodes[Elements[i].ID2];
            Elements[i].Calculate(n1, n2, Alpha, q, AmbientTemperature);
            //Elements[i].LH.PrintMatrix();
            //Elements[i].LP.PrintVector();
        }

        //Skladanie H i P
        for(int i = 0; i < NumberOfElements; i++)
        {
            //Elements[i].LH.PrintMatrix();
            H.A[i][i] += Elements[i].LH.A[0][0];
            H.A[i][i+1] += Elements[i].LH.A[0][1];
            H.A[i+1][i] += Elements[i].LH.A[1][0];
            H.A[i+1][i+1] += Elements[i].LH.A[1][1];
            P.A[i] -= Elements[i].LP.A[0];
            P.A[i+1] -= Elements[i].LP.A[1];
        }
        //H.PrintMatrix();
        //P.PrintVector();

        double []t = H.lsolve(P.A);
        Vector T = new Vector(t);
        T.PrintVector();
    }

    public void PrintData()
    {
        System.out.print("\nDane:\nIlosc elementow : " + NumberOfElements + "\nIlosc wezlow : " + NumberOfNodes);
        System.out.print("\nStrumien ciepla : " + q + "\nTemp. otoczenia : " + AmbientTemperature + "\nWspolczynnik alfa : " + Alpha + "\n");
    }

    public void PrintElements()
    {
        System.out.print("\nWypisuje elementy:");
        for(int i = 0; i < NumberOfElements; i++)
        {
            if(i != 0)  System.out.print("\n");
            System.out.print("\nElement nr." + i);
            System.out.print("\nWezly elementu : " + Elements[i].ID1 + " , " + Elements[i].ID2);
            System.out.print("\nPrzekroj : " + Elements[i].s);
            System.out.print("\nDlugosc : " + Elements[i].l);
            System.out.print("\nWspolczynnik przewodzenia : " + Elements[i].k);
        }
        System.out.print("\n");
    }

    public void PrintNodes()
    {
        System.out.print("\nWypisuje wezly:");
        for(int i = 0; i < NumberOfNodes; i++)
        {
            if(i != 0)  System.out.print("\n");
            System.out.print("\nWezel nr." + i);
            System.out.print("\nId wezlu : " + Nodes[i].ID);
            System.out.print("\nOdleglosc wezlu : " + Nodes[i].x);
            System.out.print("\nWaruenk graniczny : " + Nodes[i].BC);
            System.out.print("\nTemperatura w wezle : " + Nodes[i].t);
        }
        System.out.print("\n");
    }
}
