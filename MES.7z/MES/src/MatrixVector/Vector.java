package MatrixVector;

/**
 * Created by Chriss on 2016-11-05.
 */
public class Vector {
    public double [] A;
    public Vector(double []B)
    {
        A = B;
    }
    public Vector(int n)
    {
        A = new double[n];
        for(int i = 0; i < n; i++)
        {
            A[i] = 0;
        }
    }
    public void PrintVector()
    {
        int n = A.length;
        System.out.print("\nWypisuje wektor: \n");
        int i;
        for(i=0; i<n; i++)
        {
            System.out.print(A[i]+"\n");
        }
    }
}
