/**
 * Created by Chriss on 2016-11-05.
 */
public class Node {
    public int ID;
    public double t;
    public double x;
    public int BC; //0-brak, 1-q, 2-alfa delta t


    public Node()
    {
        ID = 0;
        t = 0;
        x = 0;
        BC = 0;
    }
}
