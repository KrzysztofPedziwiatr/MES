import MatrixVector.Matrix;
import MatrixVector.Vector;

/**
 * Created by Chriss on 2016-11-05.
 */
public class Element {
    public int ID1;
    public int ID2;
    public double s;
    public double l;
    public double k;
    public Matrix LH;
    public Vector LP;

    public Element()
    {
        ID1 = 0;
        ID2 = 0;
        s = 0;
        l = 0;
        k = 0;
        double [][]tmp = {{0,0},{0,0}};
        double []tmp2 = {0,0};
        LH = new Matrix(tmp);
        LP = new Vector(tmp2);
    }

    public void Calculate(Node a, Node b, double Alpha, double q, double ta)
    {
        double C = (s*k)/l;
        double C2 = -1 * C;
        LH.A[0][0] = LH.A[1][1] = C;
        LH.A[0][1] = LH.A[1][0] = C2;
        if(a.BC == 2)
        {
            LH.A[0][0] += Alpha*s;
            LP.A[0] = -1*Alpha*ta*s;
        }
        else if(b.BC == 2)
        {
            LH.A[1][1] += Alpha*s;
            LP.A[1] = -1*Alpha*ta*s;
        }
        if(a.BC == 1)
        {
            LP.A[0] = q*s;
        }
        else if(b.BC == 1)
        {
            LP.A[1] = q*s;
        }
    }
}
